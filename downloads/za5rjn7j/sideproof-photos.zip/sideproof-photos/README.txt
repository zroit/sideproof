SideProof: photos for a staged trial, picked from the phone's gallery

The face is YouCam's own sample face (skin_analysis_01, from the YouCam API docs). The
"product" is a digital matte filter on one half of the photo, made by a script
(backend/scripts/phone_photos.py in the repo). Baseline 2 is the same photo 2% brighter.

1. Start a trial and send 1-baseline and 2-baseline (from either folder).
2. The app shades one half of the photo. Use the folder named after that half:
   shaded-left or shaded-right.
3. Start the trial, then send 3, 4 and 5 from that folder, then Finish.

0-side-light.jpg is lit from one side: the app refuses it before anything is sent to YouCam,
so it costs no units.
